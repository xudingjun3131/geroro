<?php
class WPBakeryShortCode_VC_Text_separator extends WPBakeryShortCode {


	public function outputTitle( $title ) {
		return '';
	}
}